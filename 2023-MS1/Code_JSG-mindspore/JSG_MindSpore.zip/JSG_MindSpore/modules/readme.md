# base modules, default in per-query mode

## The visual and textual data provider are same in the two sub-settings. The Dataset4Training is different in different sub-settings, which should be reimplemeted in the corresponding sub-setting.